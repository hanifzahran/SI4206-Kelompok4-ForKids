<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Login</title>
</head>

<body style="background-color: #ffd800;">
    <!--awal Navbar -->
    <nav class="navbar navbar-expand-md navbar-light" style="background-color: #0077b6;">
        <a class=" navbar-brand" style="color: white;" href="/">FOR-KIDS</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
            </ul>
            <ul class="navbar-nav ">
                <li class="nav-item d-inline">
                    <a href="<?php echo e(route('register')); ?>" style="color: white;">Register</a>
                </li>
            </ul>
        </div>
    </nav>
    <!-- akhir navbar  -->

    <!-- memunculkan pesan error ketika password / email salah -->
    <?php if (isset($error)) : ?>
    <div class="alert alert-warning">
        <strong>Pemberitahuian : </strong> Email / Password salah
    </div>
    <?php endif; ?>

    <div class="container">
        <div class="rapikancard" style="padding-left: 350px; padding-top: 100px;">
            <div class="card w-50 shadow">
                <img class="card-img-top shadow" src="/template/img/gambar1.jpg" alt="gambar 1" style="width:100%">
                <hr>
                <!-- Awal card login -->
                <center>
                    <h3 style="color: goldenrod;">Login</h3>
                    <h6 style>FOR-KIDS</h6>
                </center>
                <div class="card-body">
                    <form action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                        <div class="rapikanform" style="padding: 10px;">
                            <div class="form-group">
                                <label for="email">Email address :</label>
                                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="masukan email anda" id="email"
                                    name="email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="pwd">Password :</label>
                                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="masukan password anda" id="pwd"
                                    name="password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox" name="remember"> Remember me?
                                </label>
                            </div>
                        </div>
                        <center><button type="submit" class="btn btn-primary" name="login">Login</button></center>
                        <br>
                        <center>
                            <p>Belum punya akun? <a href="registrasi.php">Registrasi</a></p>
                        </center>
                    </form>
                </div>
                <!-- AKhir card login -->
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
</body>

</html><?php /**PATH E:\xampp_new\htdocs\forkids\resources\views/auth/login.blade.php ENDPATH**/ ?>